import java.rmi.Remote;

public interface IEspece extends Remote{
}
