public interface ISousEspece extends IEspece {
}
